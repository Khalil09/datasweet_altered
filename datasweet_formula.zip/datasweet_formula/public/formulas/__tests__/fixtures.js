
export default {
  columns: { 'metric': 1, 'formula': 2, 'term': 0 },
  table: [
    [ 'FR-E', 33, null ],
    [ 'FR-F', 37, null ],
    [ 'FR-F', 21, null ],
    [ 'FR-J', 6, null ],
    [ 'FR-R', 16, null ],
    [ 'FR-R', 47, null ],
    [ 'FR-R', 80, null ],
    [ 'FR-U', 23, null ],
    [ 'FR-U', 3, null ],
    [ 'FR-U', 32, null ],
    [ 'FR-U', 1, null ],
    [ 'FR-U', 12, null ],
    [ 'FR-U', 1, null ],
    [ 'FR-U', 9, null ],
    [ 'FR-U', 62, null ],
    [ 'FR-U', 14, null ],
    [ 'FR-U', 24, null ],
    [ 'FR-U', 20, null ],
    [ 'FR-U', 43, null ],
    [ 'FR-U', 7, null ],
    [ 'FR-U', 59, null ]
  ]
};
